<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', '/tmp/php-errors.log');

date_default_timezone_set('UTC');

# What type of request is this?
$headers = getallheaders();
$msgType = $headers['x-amz-sns-message-type'];
if ($msgType == "SubscriptionConfirmation") {
  # Confirm the subscription request.
	# NOTE: Production code should verify the authenticity of all SNS messages by obtaining the SigningCertURL and
	# validating the signature. For more information, see:
	# http://docs.aws.amazon.com/sns/latest/dg/SendMessageToHttp.verify.signature.html
	$entityBody = file_get_contents('php://input');
	$json = json_decode($entityBody, true);
	if (json_last_error() != JSON_ERROR_NONE) {
		logProgress("JSON decoding error detected - exiting");
		exit;
	}

	$subscribeUrl = $json['SubscribeURL'];
	$result = file_get_contents($subscribeUrl);
	logProgress($json['TopicArn'], "Confirmed subscription request for topic " . $json['TopicArn']);

	exit;
} elseif ($msgType == "Notification") {
  $entityBody = file_get_contents('php://input');
  $jsonWrapper = json_decode($entityBody, true);
  if (json_last_error() != JSON_ERROR_NONE) {
    logProgress("", "JSON decoding error detected - exiting");
    exit;
  }

  $msg = $jsonWrapper['Message'];
  logProgress($msg);
}

function logProgress($message) {
	$time = date('c', time());
	file_put_contents(
		$_SERVER['DOCUMENT_ROOT'] . '/ql-debugger-output.txt',
		$time . ":" . $message . "\n",
		FILE_APPEND);
}

?>
