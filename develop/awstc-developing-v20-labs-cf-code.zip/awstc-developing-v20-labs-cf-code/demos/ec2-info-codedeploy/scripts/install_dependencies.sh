#!/bin/bash

# NOTE: We install these from the launch config, so our instances will pass our initial ELB health checks. 
# yum -y update
# yum -y install httpd php
# chkconfig httpd on
# /etc/init.d/httpd start
