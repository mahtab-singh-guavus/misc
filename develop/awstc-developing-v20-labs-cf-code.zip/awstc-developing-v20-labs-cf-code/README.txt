*****************
THIS CODE IS PROVIDED ON AN AS-IS BASIS WITHOUT ANY KIND OF WARRANTY, EITHER EXPRESS OR IMPLIED. IT IS PROVIDED FOR REFERENCE PURPOSES ONLY, AND IS NOT INTENDED FOR PRODUCTION USE. NO SUPPORT IS PROVIDED FOR RUNNING THIS CODE IN YOUR OWN ENVIRONMENT. 
*****************

Lab Design
----------

The lab-common directory contains the core of each lab, which sets up our base development environment (lab-common\base-developing-template.template). Each individual lab has its own CloudFormation template which first calls this template as a child stack: 

"BaseDevelopmentStack": {
  "Type": "AWS::CloudFormation::Stack",
  "Properties": {
    "TemplateURL": {
      "Fn::Join": [
        "",
        [
          {
            "Ref": "LabUrlPrefix"
          },
          "/lab-common/base-developing-template.template"
        ]
      ]
    },
    "Parameters": {
      "AWSAccessKey": {
        "Ref": "AWSAccessKey"
      },
      "AWSSecretAccessKey": {
        "Ref": "AWSSecretAccessKey"
      },
      "KeyName": {
        "Ref": "KeyName"
      },
      "LabUrlPrefix": {
        "Ref": "LabUrlPrefix"
      },
      "AWSAmiId": {
        "Ref": "AWSAmiId"
      },
      "ParentLabName": {
        "Ref": "LabName"
      }
    },
    "TimeoutInMinutes": "60"
  }

Using a nested stack in AWS CloudFormation enables us to share the core instances used for development across all of the labs. The individual lab's AWS CloudFormation templates then create any resources - AWS ElastiCache clusters, Amazon S3 buckets - that are specific to that lab.

When referencing this code as sample code, take note of the following parameters:

- LabUrlPrefix: Set this to your own Amazon S3 bucket, and upload all dependencies required by your scripts there. Note that the lack of any single dependency will cause the user data for the Windows and Linux instances to fail to instantiate.  
- AWSAmiId: This is a "magic parameter" in our qwikLABS environment that fetches the latest valid version of the Windows server 2012 AMI for us. Replace this with a static value corresponding to the correct value of the latest Windows Server AMI ID in your region. 

Additionally, our code contains code in the lab-common\static\install-devenv.ps1 and lab-common\static\install-devenv.sh files that downloads the sample code using in the Developing on AWS labs to the local machine. If you are using your own Amazon S3 bucket, it is probably best if you just delete this code entirely when running it in your own account. 

Finally, note that some of the dependencies necessary for running these templates - such as PyCharm - are not included in this package. 