#!/bin/bash

labUrlPrefix=$1
labName=$2

yum -y install python34 python34-pip
alternatives --set python /usr/bin/python3.4

yum install -y nodejs npm --enablerepo=epel
cd /home/ec2-user
pip install filechunkio boto3
yum remove -y java-1.7.0-openjdk
yum install -y java-1.8.0-openjdk java-1.8.0-openjdk-devel
echo 'JAVA_HOME=/usr' >> /home/ec2-user/.bash_profile
echo 'export JAVA_HOME' >> /home/ec2-user/.bash_profile
export JAVA_HOME=/usr
wget ${1}/lab-common/static/apache-ant-1.9.6-bin.zip
unzip apache-ant-1.9.6-bin.zip
chown -R ec2-user:ec2-user apache-ant-1.9.6
echo 'PATH=$PATH:/home/ec2-user/apache-ant-1.9.6/bin' >> /home/ec2-user/.bash_profile
echo 'ANT_HOME=/home/ec2-user/apache-ant-1.9.6' >> /home/ec2-user/.bash_profile
echo 'export ANT_HOME' >> /home/ec2-user/.bash_profile

npm install -g grunt-cli

skeletonName="${labName}-skeleton"
UnableToCreateWorkdir="ERROR: Unable to create workdir"
UnableToDownloadFile="ERROR: Unable to download file:"
UnableToSetUpLabSkeleton="ERROR: Unable to set up lab skeleton code"
CompletedLabSkeletonSetup="Completed lab skeleton setup in directory:"

workdir=workdir
skeletonNameZip=$skeletonName.zip
if [ ! -d "$workdir" ]; then
  mkdir workdir
  if [ ! -d "$workdir" ]; then
    echo"$UnableToCreateWorkdir",
    exit 1;
  fi
fi

cd workdir
curl -O $labUrlPrefix/$labName/static/$skeletonNameZip
if [ ! -e $skeletonNameZip ]; then
  echo "$UnableToDownloadFile $labUrlPrefix/$labName/static/$skeletonNameZip"
  exit 1;
fi

unzip -q $skeletonNameZip
chown -R ec2-user:ec2-user ../workdir

echo "$CompletedLabSkeletonSetup $labDirectoryName"
