param (
  [string] $LabUrlPrefix,
  [string] $ParentLabName
)

function devlog($txt) {
  Add-Content "c:\temp\aws\install-log.txt" ((get-date -format "T") + " " + $txt)
}

devlog("Downloading AWS SDK")
$webclient = New-Object System.Net.WebClient
$webclient.DownloadFile('http://sdk-for-net.amazonwebservices.com/latest/AWSToolsAndSDKForNet.msi','C:\temp\aws\AWSToolsAndSDKForNet.msi')

$webclient = New-Object System.Net.WebClient
$webclient.DownloadFile($LabUrlPrefix + "/lab-common/static/AdminDeployment.xml", 'C:\temp\aws\AdminDeployment.xml')
$webclient = New-Object System.Net.WebClient
$webclient.DownloadFile($LabUrlPrefix + "/lab-common/static/vs_community.exe", 'C:\temp\aws\vs_community.exe')
devlog("Installing VS Community")
Start-Process 'C:\temp\aws\vs_community.exe' -ArgumentList '/Passive /NoRestart /AdminFile C:\temp\aws\AdminDeployment.xml' -Wait
devlog("Creating VS community shortcut")
$WshShell = New-Object -comObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("C:\Users\Administrator\Desktop\VisualStudio.lnk")
$Shortcut.TargetPath = "C:\Program Files (x86)\Microsoft Visual Studio 14.0\Common7\IDE\devenv.exe"
$Shortcut.Save()

devlog("Installing AWS SDK for .NET")
Start-Process 'C:\temp\aws\AWSToolsAndSDKForNet.msi' -ArgumentList /qn -Wait
& 'c:\Program Files (x86)\Microsoft Visual Studio 14.0\Common7\IDE\devenv.exe' /setup

devlog("Downloading JDK")
$webclient = New-Object System.Net.WebClient
$webclient.DownloadFile($LabUrlPrefix + '/lab-common/nov/jdk-8u31-windows-x64.exe', "C:\temp\aws\jdk-8u31-windows-x64.exe")
devlog("Installing JDK")
Start-Process 'C:\temp\aws\jdk-8u31-windows-x64.exe' -ArgumentList /s -Wait

devlog("Downloading Eclipse")
$webclient = New-Object System.Net.WebClient
$webclient.DownloadFile($LabUrlPrefix + "/lab-common/nov/eclipse-luna-jee-aws-01222015.zip", 'C:\temp\aws\eclipse-luna-jee-aws-01222015.zip')
devlog("Unzipping Eclipse")
[System.Reflection.Assembly]::LoadWithPartialName('System.IO.Compression.FileSystem')
[System.IO.Compression.ZipFile]::ExtractToDirectory("C:\temp\aws\eclipse-luna-jee-aws-01222015.zip", "C:\")

devlog("Creating Eclipse Shortcut")
$WshShell = New-Object -comObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("C:\Users\Administrator\Desktop\Eclipse.lnk")
$Shortcut.TargetPath = "C:\eclipse\eclipse.exe"
$Shortcut.Save()

devlog("Downloading node.js")
$webclient = New-Object System.Net.WebClient
$webclient.DownloadFile($LabUrlPrefix + "/lab-common/static/node-v0.12.7-x86.msi",'C:\temp\aws\node-v0.12.7-x86.msi')
devlog("Installing node.js")
Start-Process 'C:\temp\aws\node-v0.12.7-x86.msi' -ArgumentList /qn -Wait

devlog("Downloading ANT")
$webclient = New-Object System.Net.WebClient
$webclient.DownloadFile($LabUrlPrefix + "/lab-common/static/apache-ant-1.9.6-bin.zip", "C:\temp\aws\apache-ant-1.9.6-bin.zip")
devlog("Unzipping ANT")
[System.IO.Compression.ZipFile]::ExtractToDirectory("C:\temp\aws\apache-ant-1.9.6-bin.zip", "C:\")

devlog("Downloading Python")
$webclient = New-Object System.Net.WebClient
$webclient.DownloadFile($LabUrlPrefix + "/lab-common/nov/python-3.5.0-amd64.exe", 'C:\temp\aws\python-3.5.0-amd64.exe')
devlog("Installing Python")
Start-Process 'C:\temp\aws\python-3.5.0-amd64.exe' -ArgumentList "/quiet", "InstallAllUsers=1" -Wait

devlog("Initializing environment variables")
[Environment]::SetEnvironmentVariable('Path', $env:Path + ';C:\apache-ant-1.9.6\bin;C:\Program Files\Java\jdk1.8.0_31\bin;C:\Program Files\Python 3.5;C:\Program Files\Python 3.5\Scripts', [EnvironmentVariableTarget]::Machine)
[Environment]::SetEnvironmentVariable('ANT_HOME', 'C:\apache-ant-1.9.6', [EnvironmentVariableTarget]::Machine)
[Environment]::SetEnvironmentVariable('JAVA_HOME', 'C:\Program Files\Java\jdk1.8.0_31\', [EnvironmentVariableTarget]::Machine)

# Install boto3 using pip. Since pip comes pre-installed starting with Python 3.4.
$env:Path = $env:Path + ";C:\Program Files\Python 3.5;C:\Program Files\Python 3.5\Scripts"
pip3 install boto3

devlog("Downloading PyCharm")
$webclient = New-Object System.Net.WebClient
$webclient.DownloadFile($LabUrlPrefix + "/lab-common/nov/pycharm-community-4.5.4.exe", 'C:\temp\aws\pycharm-community-4.5.4.exe')
devlog("Installing PyCharm")
Start-Process 'C:\temp\aws\pycharm-community-4.5.4.exe' -ArgumentList /S -Wait

devlog("Creating PyCharm Shortcut")
$WshShell = New-Object -comObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("C:\Users\Administrator\Desktop\PyCharm.lnk")
$Shortcut.TargetPath = "C:\Program Files (x86)\JetBrains\PyCharm Community Edition 4.5.4\bin\pycharm64.exe"
$Shortcut.Save()

# Install the skeleton code for this lab.
## Set the name of the skeleton code ZIP file for each lab.
$skeletonName=$ParentLabName + "-skeleton"

## Messages
$UnableToCreateWorkdir="ERROR: Unable to create workdir"
$UnableToDownloadFile="ERROR: Unable to download file:"
$UnableToSetUpLabSkeleton="ERROR: Unable to set up lab skeleton code"
$CompletedLabSkeletonSetup="Completed lab skeleton setup in directory:"

$workdir="workdir"
$skeletonNameZip=$skeletonName + ".zip"

if(!(Test-Path $workdir )) {
    New-Item -ItemType directory -Path $workdir
    if(!(Test-Path $workdir )) {
      exit 1
    }
}

cd $workdir
$workdirPath=pwd
$wgetFilePath=$LabUrlPrefix + "/" + $ParentLabName + "/" + "static" + "/" + $skeletonNameZip
wget $wgetFilePath -outfile "$skeletonNameZip"

if(!(Test-Path $skeletonNameZip )) {
  echo $UnableToDownloadFile + $wgetFilePath
  exit 1
}
# unzip
$zipFullPath = $workdirPath.toString() + "\" + $skeletonNameZip
$zipSavePath = "C:\temp\" + $workdir
[System.IO.Compression.ZipFile]::ExtractToDirectory($zipFullPath, $zipSavePath)
